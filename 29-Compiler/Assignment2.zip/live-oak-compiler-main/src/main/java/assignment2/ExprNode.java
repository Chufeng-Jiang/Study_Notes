package assignment2;

public class ExprNode extends ASTNode{
    ASTNode child;

    public ExprNode(){
        nodeType = "Expr";
    }
}
