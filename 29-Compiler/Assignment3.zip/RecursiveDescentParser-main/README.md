A recursvive descent parser that translates LiveOak (high level object-oriented langauge) into SaM assembly. 
